package com.perficient.questions.model;

public class Questions {

	private int questionno;  
	private String question ="hello quest";  
	private String a;  
	private String b;
	private String c;
	private String d;
	private String correctanswer;  
	  
	public int getquestionno() {  
	    return questionno;  
	}  
	public void setquestionno(int questionno) {  
	    this.questionno = questionno;  
	}  
	public String getquestion() {  
	    return question;  
	}  
	public void setquestion(String question) {  
	    this.question = question;  
	}  
	public String geta() {  
	    return a;  
	}  
	public void seta(String a) {  
	    this.a = a;  
	}  
	public String getb() {  
	    return b;  
	}  
	public void setb(String b) {  
	    this.b = b;  
	}  
	public String getc() {  
	    return c;  
	}  
	public void setc(String c) {  
	    this.c = c;  
	}  
	public String getd() {  
	    return d;  
	}  
	public void setd(String d) {  
	    this.d = d;  
	}  
	public String getcorrectanswer() {  
	    return correctanswer;  
	}  
	public void setcorrectanswer(String correctanswer) {  
	    this.correctanswer = correctanswer;  
	}  
	  
	}  
